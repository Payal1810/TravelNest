export default function HomeComp(){
    return (
        <div className="home-container  d-flex justify-content-center align-items-center vh-100">
            <h1>Welcome to TravelNest</h1>
        </div>
    )
}